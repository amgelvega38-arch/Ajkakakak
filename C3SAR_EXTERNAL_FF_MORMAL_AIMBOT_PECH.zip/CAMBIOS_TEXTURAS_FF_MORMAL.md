# Integración de TEXTURAS en FF MORMAL

- Se incorporó `M-TEXTURAS ALOK FF MAX.3105` como `TEXTURAS.3105`.
- Se migró el sobre cifrado de esquema 9 a esquema 2 compatible con el codec actual, conservando el UUID y el contenido del reemplazo.
- Se verificaron AES-GCM, huella de clave y SHA-256 del recurso.
- Se registró el paquete como recurso Xcode.
- Se añadió TEXTURAS dentro de FF MORMAL con estado independiente y flujo de aplicar/restaurar.
- La compilación Xcode y prueba en iPhone aún requieren entorno iOS.
